clc,clear,close all
function f=fact(n)
