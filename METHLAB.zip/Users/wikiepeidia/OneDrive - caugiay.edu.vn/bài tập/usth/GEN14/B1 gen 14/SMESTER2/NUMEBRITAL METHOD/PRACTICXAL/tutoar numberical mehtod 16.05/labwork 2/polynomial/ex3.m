clc,clear,close all
t=0:2:20;
m=68.1;
cd=0.25;
g=9.8;
v=sqrt(g*m/cd)*tanh(sqrt(g*cd/m)*t);
plot(t,v)