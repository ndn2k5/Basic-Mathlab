%Enter left hand side of the matrx
A = [5, -2, 3;
     3, 9, -1;
     2, -1, -7];

%Enter right hand side
b = [-1;
      2;
      3];

x0 = [0; 0; 0]; % Initial guess
iterations = 6;

jacobi(A, b, x0, iterations);