clc,clear ,close all
A=[7 11;10 8;1 0;0 1];
B=[77;80;9;6];
Z=[-150;-175];
x=linprog(Z,A,B);
max_profit=Z'*x
