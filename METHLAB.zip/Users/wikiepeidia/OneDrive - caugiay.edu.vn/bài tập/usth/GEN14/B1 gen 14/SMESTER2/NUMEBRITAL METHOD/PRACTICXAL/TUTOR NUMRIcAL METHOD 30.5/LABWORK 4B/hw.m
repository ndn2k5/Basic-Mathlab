clc, clear all, close all
disp=[0.1;0.17;0.27;0.35;0.39;0.42;0.43;0.44]';
force=[100000;200000;300000;400000;500000;600000;700000;800000]';
% Perform linear regression using fit function
[a0, a1, r2] =linear_regression(disp, force)