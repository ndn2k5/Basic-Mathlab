clc,clear,close all
sym x;
step=20;
desired_error=10^-8;
current_error=1;
x=0;
while current_error>desired_error
    x=x-f(x)/df(x)
    current_error=abs(f(x));
end
function y=f(x)
y=x^3+x-3;
end
function y=df(x)
y=3*x^2+1;
end
