clc,clear,close all
x=linspace(0,9);
y=linspace(0,6);
[X,Y]=meshgrid(x,y);
condition1=7.*X+11.*Y<77;
condition2=10.*X+8.*Y<80;
condition=condition1.*condition2;
surf(X,Y,condition);
view(0,90);
title("FEASIBLE REGION");
xlabel("x");
ylabel("y");