%pham the minh
%23bi14279
%sep 24 2005
% a=2 b=7 c=9 d=24

clc,close,clear all
syms x;

step=1;
desired_error=10^-8;
current_error=1;
x=0.8;

while step>0
    x=x-f(x)/df(x)
    step=step-1;
end %quest b
function y = f(x)
    y = x^3+x^2-1/x;
end
function y = df(x)
    y = 3*x^2+2*x+1/x^2;
end

function [root,fx,ea,iter]=bisection(func,xl,xu,es,maxit)
% bisect: root location zeroes
% [root,fx,ea,iter]=bisect(func,xl,xu,es,maxit,p1,p2,...):
% uses bisection method to find the root of func
% input:
% func = name of function
% xl, xu = lower and upper guesses
% es = desired relative error (default = 0.0001%)
% maxit = maximum allowable iterations (default = 50)
% p1,p2,... = additional parameters used by func
% output:
% root = real root
% fx = function value at root
% ea = approximate relative error (%)
% iter = number of iterations
if nargin<3,error('at least 3 input arguments required'),end
test = func(xl)*func(xu);
if test>0,error('no sign change'),end
if nargin<4||isempty(es), es=0.0001;end
if nargin<5||isempty(maxit), maxit=50;end
iter = 0; xr = xl; ea = 100;
while (1)
xrold = xr;
xr = (xl + xu)/2;
iter = iter + 1;
if xr ~= 0,ea = abs((xr - xrold)/xr) * 100;end
test = func(xl)*func(xr);
if test < 0
xu = xr;
elseif test > 0
xl = xr;
else
ea = 0;
end
if ea <= es || iter >= maxit,break,end
end
root = xr;
fx = func(xr);
end