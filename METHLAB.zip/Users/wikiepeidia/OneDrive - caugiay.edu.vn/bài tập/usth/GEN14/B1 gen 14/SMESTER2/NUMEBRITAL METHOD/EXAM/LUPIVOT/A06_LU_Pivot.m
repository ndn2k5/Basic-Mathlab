A = [
    2 -6 -1;
    -3 -1 7; 
    -8 1 -2
];
b = [-38;-34;-20];%MATRIX NO NEED TRANPOSE.


[L,U,P] = LU_pivot(A);
L
U
P

Pb = P * b;
z = L \ Pb;
x = U \ z;

disp('Solution x =');
disp(x);