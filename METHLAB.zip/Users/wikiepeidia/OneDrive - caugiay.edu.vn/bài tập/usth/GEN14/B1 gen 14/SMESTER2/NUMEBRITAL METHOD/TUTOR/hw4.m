clc, clear all, close all

% Given data points for displacement (x) and force (F)

% Given data points for the proportion of the bottom people in a country (x) 
% and the proportion of the country's income received (y)
x = [0; 0.2; 0.4; 0.6; 0.8; 1];
y = [0; 0.031; 0.114; 0.256; 0.485; 1];

% Fit a 2nd order polynomial to the data
p = polyfit(x, y, 2);

% Extract the coefficients a, b, and c from the fitting result
a = p(1);
b = p(2);
c = p(3);

% Display the polynomial equation
disp(['L(x) = ', num2str(a), 'x^2 + ', num2str(b), 'x + ', num2str(c)]);

% Plot the original data and the fitted polynomial curve for visualization
figure;
hold on;
scatter(x, y, 'bo'); % Plot the original data points
x_fit = linspace(min(x), max(x), 100); % Create x values for the fitted curve
y_fit = polyval(p, x_fit); % Compute the fitted curve values
plot(x_fit, y_fit, 'r-'); % Plot the fitted curve
xlabel('Proportion of the bottom people in a country (x)');
ylabel('Proportion of the country''s income received (y)');
title('2nd Order Polynomial Fit of GINI Index Data');
legend('Data Points', 'Fitted Curve');
hold off;