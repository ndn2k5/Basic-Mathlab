clc,clear,close all
A=[20 5; 0.04 0.12;1 1];
B=[9500;40;500];
Z=[-45;-20];
x=linprog(Z,A,B);
max_profit=Z'*