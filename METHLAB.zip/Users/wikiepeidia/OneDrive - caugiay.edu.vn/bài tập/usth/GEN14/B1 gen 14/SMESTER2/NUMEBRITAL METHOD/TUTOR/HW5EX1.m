%Pham THe Minh 23bi14279


clc; clear; close all

A = [5 2; 6 6; 2 4; -1 0; 0 -1];
B = [40; 60; 32; 0; 0];
Z = [-6; -8];
[t, fval, exitflag, output, lambda] = linprog(Z, A, B);
max_value = -fval
x = t(1)
y = t(2)

u = linspace(0, 20, 400);
v = linspace(0, 20, 400);
[U, V] = meshgrid(u, v);
condi1 = 5*U + 2*V <= 40;
condi2 = 6*U + 6*V <= 60;
condi3 = 2*U + 4*V <= 32;
condi = condi1 & condi2 & condi3;


figure;
hold on;


contourf(U, V, condi, [1 1], 'LineColor', 'none', 'FaceAlpha', 0.5);


range = linspace(0, 10, 400);
y1 = (40 - 5 * range) / 2;
y2 = (60 - 6 * range) / 6;
y3 = (32 - 2 * range) / 4;


plot(range, y1, 'r', 'DisplayName', '5x + 2y \leq 40');
plot(range, y2, 'g', 'DisplayName', '6x + 6y \leq 60');
plot(range, y3, 'b', 'DisplayName', '2x + 4y \leq 32');


plot(t(1), t(2), 'ro', 'MarkerSize', 10, 'LineWidth', 2);


xlim([0 10]);
ylim([0 10]);
xlabel('x');
ylabel('y');
title('OPTIMAL SOLUTION FOR HOMEWORK 5- Pham THe Minh 23bi14279');
legend show;
hold off;
