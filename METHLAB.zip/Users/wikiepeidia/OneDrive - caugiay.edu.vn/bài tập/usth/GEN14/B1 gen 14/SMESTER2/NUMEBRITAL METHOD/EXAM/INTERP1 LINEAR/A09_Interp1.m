pkg load optim %remove if ur using matlab

x = [0.00000 0.78540 1.57080 2.35619 3.14159 3.92699 4.71239 5.49779 6.28319 ];
y = [0.00000 0.70711 1.00000 0.70711 0.00000 -0.70711 -1.00000 -0.70711 0.00000 ];

xq = [3.0000, 4.5000];
method = 'linear';

vq_linear = interp1(x,y,xq,method);

disp('Linear interpolation results:');
disp(['f(3.00000) = ', num2str(vq_linear(1))]);
disp(['f(4.50000) = ', num2str(vq_linear(2))]);

% Plot the results
figure;
plot(x, y, 'o', 'MarkerFaceColor', 'blue');
hold on;
plot(xq, vq_linear, 'x', 'MarkerSize', 10, 'Color', 'red');
plot(x, interp1(x, y, x, 'linear'), '-r');
legend('Data', 'Linear Interpolated Points', 'Linear Interpolation');
xlabel('x');
ylabel('y');
title('Linear Interpolation using interp1');
hold off;
input("Enter to quit");