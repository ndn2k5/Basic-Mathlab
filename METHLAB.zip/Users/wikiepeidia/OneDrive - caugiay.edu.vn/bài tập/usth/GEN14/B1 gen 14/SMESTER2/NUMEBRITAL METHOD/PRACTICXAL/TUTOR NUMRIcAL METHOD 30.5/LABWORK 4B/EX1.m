clc,clear all,close all

mass=[400,70,45,2,0.3,0.16];
metabolism=[270,82,50,4.8,1.45,0.97];
[a0, a1, r2] =linear_regression(mass, metabolism)
tiger_meta = a0+ a1*350