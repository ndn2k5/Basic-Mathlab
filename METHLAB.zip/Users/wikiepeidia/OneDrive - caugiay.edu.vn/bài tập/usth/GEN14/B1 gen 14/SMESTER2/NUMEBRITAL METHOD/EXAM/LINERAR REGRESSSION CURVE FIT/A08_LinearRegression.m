x = [0.10, 0.17, 0.27, 0.35];%X-LINE
y = [10 20 30 40];%Y-LINE

[a0,a1,r2] = linear_regression(x,y);
fprintf("The line fitting is y = %.5f + %.5fx\n",a0,a1);

input("Enter to quit")