clc,clear,close all
func =@(x) 0.2+25*x-200*x.^2+675*x.^3-900*x.^4+400*x.^5;
x=linspace(0,0.8);
y=func(x);
I=quad(func,0,0.8)