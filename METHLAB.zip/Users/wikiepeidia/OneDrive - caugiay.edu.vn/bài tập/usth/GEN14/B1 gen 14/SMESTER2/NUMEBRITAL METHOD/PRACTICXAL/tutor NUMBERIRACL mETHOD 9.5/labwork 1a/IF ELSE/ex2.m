clc;        % Clear command window
clear all;  % Clear all variables from the workspace
close all;  % Close all open figures
syms x y
x=input("enter x ")

if x==40||x==0
    error("invalid inputs")
end
if 0<x<10
    y=4*x;
elseif 10<x<40
    y=10*x
else
    y=x;
end
disp(['y value',num2str(y)])