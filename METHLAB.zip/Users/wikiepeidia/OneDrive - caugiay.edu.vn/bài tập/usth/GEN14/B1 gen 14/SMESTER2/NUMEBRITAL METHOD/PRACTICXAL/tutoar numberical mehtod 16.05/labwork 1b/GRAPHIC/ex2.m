clc,clear,close all
x=linspace(-1.5,1.5);
y1=exp(-x/2);
y2=x.^4-x.^2;
plot(x,y1,color="red");
hold on
plot(x,y2,color="blue");
legend("y=exp(-x/2)","y2=x.^4-x.^2",location="best");