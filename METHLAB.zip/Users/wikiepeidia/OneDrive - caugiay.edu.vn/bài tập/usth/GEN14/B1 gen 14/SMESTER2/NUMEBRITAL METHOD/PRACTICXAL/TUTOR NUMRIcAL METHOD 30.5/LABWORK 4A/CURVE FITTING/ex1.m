clc, clear all, close all
weight=[40;63;62;68;64;45;50;66;67];
JHI=[1450;3817;3708;4300;3950;1896;2339;4200;4312];
func = @(a, weight)  a(1)*exp(a(2)*weight);
a0 = [200, 0.05];
x = lsqcurvefit(func, a0, weight, JHI);
plot(weight,JHI,"ko");
hold on
w=linspace(weight(1),weight(end));
plot(w,func(x,w),"b-");
title("weight vs JHI");
xlabel("wieght kg");
ylabel("JHI");
legend("raw data","fit line","Location","best");