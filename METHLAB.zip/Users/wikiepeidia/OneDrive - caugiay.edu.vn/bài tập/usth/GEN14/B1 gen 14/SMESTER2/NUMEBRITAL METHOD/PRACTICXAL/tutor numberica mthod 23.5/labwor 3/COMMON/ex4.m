clc,clear all,close all
x=[0 2; 0 2;4 4];
y=[2 0;3 1;2 0];
c = [0:1];

fill(x,y,c)