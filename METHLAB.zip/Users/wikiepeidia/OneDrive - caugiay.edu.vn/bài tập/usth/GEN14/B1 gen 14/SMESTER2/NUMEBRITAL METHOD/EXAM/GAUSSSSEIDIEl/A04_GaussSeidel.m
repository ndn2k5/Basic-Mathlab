%Enter matrix here
A = [4, -1, -2;
     -3, 5, 1;
     -1, -1, 3];

b = [4;
     7;
     3];

x0 = [0; 0; 0]; % Initial guess
iterations = 10;

GaussSeidel(A, b, x0, iterations);