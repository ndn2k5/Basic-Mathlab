clc;        % Clear command window
clear all;  % Clear all variables from the workspace
close all;  % Close all open figures
S1=0;
S2=1;
S3TEMP=0;
S3TEMP2=0;
S3=0;
for k=1:1:1000
    S1=S1+k^2;
end
disp(['Sum 1: ', num2str(S1)]);
for j=1:1:20
    S2=S2*j;
end
disp(['Sum 2: ', num2str(S2)]);
for m=1:4:1001
    S3TEMP=S3TEMP+1/m;
end
for n=3:4:1003
    S3TEMP2=S3TEMP2+1/n;
end
S3=S3TEMP-S3TEMP2;
disp(['Sum 3: ', num2str(S3)]);
clear S3TEMP2;
clear S3TEMP;