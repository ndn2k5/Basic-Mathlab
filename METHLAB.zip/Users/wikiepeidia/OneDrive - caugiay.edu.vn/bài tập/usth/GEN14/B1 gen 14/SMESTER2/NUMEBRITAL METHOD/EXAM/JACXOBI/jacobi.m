function jacobi(A, b, x0, iterations)
  % A: Coefficient matrix
  % b: Right-hand side vector
  % x0: Initial guess vector
  % iterations: Number of iterations

  n = length(b);
  x = x0;
  x_new = x0;

  % Define the update functions dynamically
  f = cell(n, 1);
  for i = 1:n
    f{i} = @(x) (b(i) - A(i, [1:i-1, i+1:n]) * x([1:i-1, i+1:n])) / A(i, i);
  end

  % Error calculation function
  function e = calError(new, old)
    e = abs((new - old) ./ (new + eps)) * 100; % Adding eps to avoid division by zero
  end

  for k = 1:iterations
    x_old = x;

    for i = 1:n
      x_new(i) = f{i}(x_old);
    end

    x = x_new;
    errors = calError(x, x_old);

    fprintf("Iteration %d: ", k);
    for i = 1:n
      fprintf("x%d = %.5f ", i, x(i));
    end
    fprintf(" | ");
    for i = 1:n
      fprintf("e%d = %.3f ", i, errors(i));
    end
    fprintf("\n");
  end
end
