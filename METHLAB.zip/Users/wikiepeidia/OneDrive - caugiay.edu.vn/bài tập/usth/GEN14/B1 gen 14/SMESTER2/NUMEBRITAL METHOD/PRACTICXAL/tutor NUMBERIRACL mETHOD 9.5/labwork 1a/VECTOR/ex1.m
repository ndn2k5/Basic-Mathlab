clc,close,clear all
x=[1 2 3 4 5]
x(3)+x(2)