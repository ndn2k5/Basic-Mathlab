clc,close,clear all
a=[1:1:100]
sum(a)