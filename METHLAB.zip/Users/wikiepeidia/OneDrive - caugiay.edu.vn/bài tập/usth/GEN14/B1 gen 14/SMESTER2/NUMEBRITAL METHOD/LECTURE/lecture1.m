clc
clear all
close all
%%
A = [2 1 -1; -3 -1 2; -2 1 2]
B= [8 -11 -3 ]
%

% 2nd method
y = A\B'
% 3rd method
z = inv(A)*B'