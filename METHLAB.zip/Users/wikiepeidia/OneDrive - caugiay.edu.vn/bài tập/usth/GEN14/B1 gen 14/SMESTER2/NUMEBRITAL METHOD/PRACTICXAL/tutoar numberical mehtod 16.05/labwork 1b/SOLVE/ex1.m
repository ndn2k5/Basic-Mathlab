clc,clear,close all
syms x;

fa=solve(27*x^3-3x+1,x)

func=@(x)67*x+32;


fb=fzero(func,0);

syms p q;
fc=solve(x.^3+p*x+q,x,"MaxDegree",3);

fd1=solve(exp(x)-8*x+4,x)
fd2=fzero(@(x)exp(x)-8*x+4,0)