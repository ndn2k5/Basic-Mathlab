f = @(x) 1/(1+x^2);

a = -3;
b = 3;

% Gauss quadrature 2 points
x1 = -sqrt(1/3);
x2 = sqrt(1/3);
w1 = 1;
w2 = 1;

I_gauss = 0.5 * (b-a) * (w1*f(0.5*(b-a)*x1 + 0.5*(b+a)) + w2*f(0.5*(b-a)*x2 + 0.5*(b+a)));

fprintf('Gauss Quadrature (2 points): %.5f\n', I_gauss);