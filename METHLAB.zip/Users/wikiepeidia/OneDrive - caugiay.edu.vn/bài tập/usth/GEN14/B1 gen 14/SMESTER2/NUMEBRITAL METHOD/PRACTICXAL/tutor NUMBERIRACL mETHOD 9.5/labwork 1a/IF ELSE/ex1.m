clc;        % Clear command window
clear all;  % Clear all variables from the workspace
close all;  % Close all open figures

n=input("enter n:   ")
if -1<=n<=1
    error("invalid inout")
end
if n>1
    m=n+1
elseif n<1
    m=n-1
end