clc,clear,close all
f1=@(x1,x2)x1^2+x1*x2-10; %function y=f1(x1,x2).....end
f2=@(x1,x2)x2+3*x1*x2^2-57;
ezplot(f1)
hold on
ezplot(f2)
x0=[-2 -2];
fsolve(@root2d,x0)
function F = root2d(x)
F(1) = x(1)^2 + x(1)*x(2) - 10;
F(2) = x(2) +3*x(1)*x(2)^2 -57;
end


