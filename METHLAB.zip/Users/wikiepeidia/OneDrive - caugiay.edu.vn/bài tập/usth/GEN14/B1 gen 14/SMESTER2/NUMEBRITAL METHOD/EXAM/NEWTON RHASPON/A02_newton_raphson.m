% pkg load symbolic;  % Remove if you're using matlab
syms x;

%Enter your function below:
f_sym = exp(-0.5*x)*(4-x)-2; %E^: EXP()

f = matlabFunction(f_sym);
df = matlabFunction(diff(f_sym, x)); %Automatically find the derivative

%Initial guess
x_val = 0; %HUESS
iterations = 5;

for i = 1:iterations
    prev_x = x_val;
    x_val = x_val - f(x_val) / df(x_val);
    newerror = abs((x_val - prev_x) / x_val) * 100;
    fprintf('Iteration %d : x = %.5f , error = %.2f\n', i, x_val, newerror);
end
