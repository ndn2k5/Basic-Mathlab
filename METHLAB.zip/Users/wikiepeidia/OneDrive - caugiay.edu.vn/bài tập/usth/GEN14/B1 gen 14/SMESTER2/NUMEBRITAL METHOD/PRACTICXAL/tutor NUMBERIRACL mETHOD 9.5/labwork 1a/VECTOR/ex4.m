clc,close,clear all
syms x y
x=1
y=2
x+y