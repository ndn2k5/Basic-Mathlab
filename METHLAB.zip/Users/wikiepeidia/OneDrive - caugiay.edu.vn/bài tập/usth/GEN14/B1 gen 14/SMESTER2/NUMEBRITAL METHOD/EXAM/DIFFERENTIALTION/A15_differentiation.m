f = @(x) x^2 * cos(x);

target_x = 0.4;
h = 0.1;
true_value = -0.9125; %ignore if not asking for error compared to real value

%forward
df_for = (f(target_x+h) - f(target_x))/h;
e1 = abs((df_for-true_value)/true_value)*100;
fprintf("Forward: y' = %.5f with error %.4f\n",df_for,e1);

%backward
df_back = (f(target_x) - f(target_x-h))/h;
e2 = abs((df_back-true_value)/true_value)*100;
fprintf("Backward: y' = %.5f with error %.4f\n",df_back,e2);

%central
df_cen = (f(target_x+h)-f(target_x-h))/(2*h);
e3 = abs((df_cen-true_value)/true_value)*100;
fprintf("Central: y' = %.5f with error %.4f\n",df_cen,e3);