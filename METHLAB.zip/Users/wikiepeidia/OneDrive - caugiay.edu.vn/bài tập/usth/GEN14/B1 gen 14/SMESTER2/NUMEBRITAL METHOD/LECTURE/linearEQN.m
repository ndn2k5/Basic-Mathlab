clc,clear,close all
% Define the augmented matrix (Aug)
% Example system of equations:


A = [7,2,-3;2,5,-3;1,-1,-6];
b = [-12,-20,-26];
Aug = [A b'];

[n, nb] = size(Aug); % n is the number of equations, nb is n+1 (augmented part)

% Gaussian elimination
for k = 1:n-1
    for i = k+1:n
        factor = Aug(i,k) / Aug(k,k);
        Aug(i,k:nb) = Aug(i,k:nb) - factor * Aug(k,k:nb);
    end
end

% Back substitution
x = zeros(n,1); % Initialize solution vector
x(n) = Aug(n,nb) / Aug(n,n);
for i = n-1:-1:1
    x(i) = (Aug(i,nb) - Aug(i,i+1:n) * x(i+1:n)) / Aug(i,i);
end

% Display the solution
disp('Solution vector x:');
disp(x);
