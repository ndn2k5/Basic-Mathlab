clc;
clear;
close all;

% Define the new, smaller range for x and y
u = linspace(0, 10, 400);
v = linspace(0, 10, 400);
[U, V] = meshgrid(u, v);

% Define the constraints
condi1 = 5*U + 2*V <= 40;
condi2 = 6*U + 6*V <= 60;
condi3 = 2*U + 4*V <= 32;

% Calculate the combined feasible region
condi = condi1 & condi2 & condi3;

% Plot the feasible region using 'contour' to highlight the region
figure;
hold on;
contourf(U, V, condi, [1 1], 'LineColor', 'none', 'FaceAlpha', 0.5);

% Plot the constraint lines
x_range = linspace(0, 20, 400);
y1 = (40 - 5 * x_range) / 2;
y2 = (60 - 6 * x_range) / 6;
y3 = (32 - 2 * x_range) / 4;

plot(x_range, y1, 'r', 'DisplayName', '5x + 2y \leq 40');
plot(x_range, y2, 'g', 'DisplayName', '6x + 6y \leq 60');
plot(x_range, y3, 'b', 'DisplayName', '2x + 4y \leq 32');

% Define the coefficients of the constraints
A = [5 2; 6 6; 2 4; -1 0; 0 -1];
B = [40; 60; 32; 0; 0];

% Define the coefficients of the objective function (for maximization)
Z = [-6; -8];

% Solve the linear programming problem
[x, fval, exitflag, output] = linprog(Z, A, B);

% Since the objective function was defined with negative coefficients for maximization
max_value = -fval; % negate the result to get the maximized value

% Display the results
fprintf('Optimal values:\n');
fprintf('x = %.2f\n', x(1));
fprintf('y = %.2f\n', x(2));
fprintf('Maximum value of the objective function = %.2f\n', max_value);

% Plot the optimal point
plot(x(1), x(2), 'ro', 'MarkerSize', 10, 'LineWidth', 2);

% Set limits and labels
xlim([0 10]);
ylim([0 10]);
xlabel('x');
ylabel('y');
title('SOLUTION');
legend show;
hold off;