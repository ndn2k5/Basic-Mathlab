clc; clear all; close all;

A = [2 -6 -1;-3 -1 7;-8 1 -2];
b = [-38 -34 -20]';

% Perform LU decomposition with partial pivoting
[L, U, P] = lu(A);

% Solve Ly = Pb
d = L \ (P * b);

% Solve Ux = y
X = U \ d;
disp(L)
disp(U)