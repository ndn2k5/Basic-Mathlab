f = @(x,y) x + y;
h = 0.2;
target_x = 0.6;

% Initial condition
x = 0;
y = 1;

steps = (target_x - x) / h;

fprintf('Step 0: x = %.5f, y = %.5f\n', x, y);
for i = 1:steps
    x_next = x + h;
    y = (y + h * x_next) / (1 - h); %THIS IS ONLY TRUE FOR THIS F = X + Y FUNCTION, YOU NEED TO MODIFY THIS LINE
    x = x_next;
    fprintf('Step %d: x = %.5f, y = %.5f\n', i, x, y);
end