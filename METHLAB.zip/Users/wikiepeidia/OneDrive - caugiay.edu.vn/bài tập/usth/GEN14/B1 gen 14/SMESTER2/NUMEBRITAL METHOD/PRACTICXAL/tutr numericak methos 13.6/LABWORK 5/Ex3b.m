clc,clear,close all
syms x y z;
func=@(x,y,z)x.^2*exp(y)-5*z.^2;
f=func(x,y,z);
I=int(f,x)
D2=diff(f,z,2)
