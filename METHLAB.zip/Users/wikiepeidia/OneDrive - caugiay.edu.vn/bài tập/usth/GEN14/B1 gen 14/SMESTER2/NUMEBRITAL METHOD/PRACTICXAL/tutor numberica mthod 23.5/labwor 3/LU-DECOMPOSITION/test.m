% Define the matrix A
A = [2 -6 -1;
    -3 -1 7;
    -8 1 -2];

% Get the size of matrix A
[n, ~] = size(A);

% Initialize L as an identity matrix and U as a copy of A
L = eye(n);
U = A;

% Perform Naive Gauss Elimination
for k = 1:n-1
    for i = k+1:n
        L(i,k) = U(i,k) / U(k,k); % Compute the multiplier
        U(i,k:n) = U(i,k:n) - L(i,k) * U(k,k:n); % Eliminate x_k from row i
    end
end

% Display the result
disp('Matrix L:');
disp(L);
disp('Matrix U:');
disp(U);