clc,clear all,close all
a=[2 1;1 2];
e=eig(a);
[ev,dv]=eig(a)