%Use bisection to find the root of f(x) = 0 ưith iteration OF ERROR TO CHECK
f = @(x) -0.6*x^2 + 2.4*x + 5.5;
%Initial guess:
x1 = 5;
x2 = 10;
%Constraints:
minError = 0.005;%MIN ERROR TO STOP LOOP
iterations = 100;

%Solve
[root,fx,ea,iter] = bisection(f,x1,x2,minError,iterations);

