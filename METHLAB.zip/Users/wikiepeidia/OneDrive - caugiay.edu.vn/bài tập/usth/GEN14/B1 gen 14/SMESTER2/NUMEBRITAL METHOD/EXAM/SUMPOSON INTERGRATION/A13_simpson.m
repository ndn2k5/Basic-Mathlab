f = @(x) 1/(1+x^2);
a = -3;%(LOW)
b = 3;%HIGH

%1/3 rule
n = 2;
h = (b-a)/n;
mid = a + h;
I = (1/6) * (b-a) * (f(a) + 4*f(mid) + f(b));
fprintf('Simpson 1/3: %.5f\n', I);

%3/8 rule
I_38 = (b-a) * (f(a) + 3*f((2*a+b)/3) + 3*f((a+2*b)/3) + f(b)) / 8;
fprintf('Simpson 3/8: %.5f\n', I_38);