clc,clear,close all
syms x;
func=@(x)x.^2*exp(x)-5*x.^3;
y=func(x);
I=int(y,x)
D1=diff(y,x)
D2=diff(y,x,2)