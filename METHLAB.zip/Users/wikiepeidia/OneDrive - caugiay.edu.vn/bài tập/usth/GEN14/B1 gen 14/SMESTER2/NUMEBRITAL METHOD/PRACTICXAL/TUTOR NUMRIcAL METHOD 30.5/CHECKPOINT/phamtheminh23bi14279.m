clc,clear all,close all
hours=[3;5;4;4;2;3];
score=[17.2;19;18.3;16.7;15.6;16.4];
f=fit(hours,score,"poly1");
plot(f,hours,score)

TWOHOURS=f(2.5)
SEVENHOURS=f(7)

% studying for 2,5 hours will get 16.1 score
%studying for 7 hours will get more than maximum score 
%therefore the best time to study ís about 6 hours to get the most optimal
%score