% Objective function coefficients (for maximization)
% We need to convert maximization to minimization by taking the negative.
c = [-6; -8]; % Profit per unit for products x and y, represented as [-6 -8] because linprog performs minimization.

% Coefficients matrix for inequality constraints
A = [
    5 2;  % Coefficients from 5x + 2y <= 40
    6 6   % Coefficients from 6x + 6y <= 60
];

% Right-hand side vector for inequality constraints
b = [
    40;  % Right-hand side of 5x + 2y <= 40
    60   % Right-hand side of 6x + 6y <= 60
];

% Coefficients matrix for equality constraints
Aeq = [
    2 4  % Coefficients from 2x + 4y = 32
];

% Right-hand side vector for equality constraints
beq = [
    32   % Right-hand side of 2x + 4y = 32
];

% Lower bounds (non-negative constraints)
lb = [0; 0]; % Lower bounds for x and y (x >= 0 and y >= 0)

% Solve the linear programming problem
[x, fval, exitflag, output, lambda] = linprog(c, A, b, Aeq, beq, lb);

% Since we minimized the negative of the objective function, we need to take the negative of fval to get the maximized value.
max_value = -fval;
x_val = x(1);
y_val = x(2);

% Display the results
disp('Solution:');
disp(['x (Product X): ', num2str(x_val)]);
disp(['y (Product Y): ', num2str(y_val)]);
disp('Objective function value (maximized):');
disp(max_value);

