x = [40, 63, 62, 68, 64, 45, 50, 66, 67];
y = [1450, 3817, 3708, 4300, 3950, 1896, 2339, 4200, 4312];

degree = 1;

p = polyfit(x, y, degree);
%p = p1 x^n + p2 x^n-1 + p3 x^n-2 + ....
p 


% Evaluate the polynomial at the given x values
y_fit = polyval(p, x);
plot(x, y, 'o', x, y_fit, '-');
xlabel('x');
ylabel('y');
title('Polynomial Fit of Degree 1');

input("Enter to quit");