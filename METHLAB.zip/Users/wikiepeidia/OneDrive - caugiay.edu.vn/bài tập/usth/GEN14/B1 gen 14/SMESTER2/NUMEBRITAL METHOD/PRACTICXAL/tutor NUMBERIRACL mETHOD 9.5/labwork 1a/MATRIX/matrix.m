clc,close,clear all
M=[0 0 0; 0 0 0; 0 0 0]
A1=zeros(3)
A=diag([1 1 1])
B=A'
D=A+B
E=A-B;
F=A*B
G=A.*B
A2=A(1:2,1:2)
B1=B(2:3,2:3)
H=A(1:3)
I=A(1:3,1)
J=A(:,1)