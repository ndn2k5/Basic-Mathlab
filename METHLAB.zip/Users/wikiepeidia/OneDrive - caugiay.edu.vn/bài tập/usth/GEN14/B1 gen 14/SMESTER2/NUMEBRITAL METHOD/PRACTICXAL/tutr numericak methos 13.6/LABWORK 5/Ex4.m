clc,clear,close all

func =@(x) 0.2+25*x-200*x.^2+675*x.^3-900*x.^4+400*x.^5;
dfunc=@(x)2000*x.^4 - 3600*x.^3 + 2025*x.^2 - 400*x + 25;

x0=0.5;
exact_value=dfunc(x0);

step=0.01;
x=0:step:1;
y=func(x);

dy=diff(y)/step;

p=find(x==x0);
d=dy(p);

f=forward(y,x,p)
b=backward(y,x,p)
c=central(y,x,p)

function d = forward(y,x,p)
d = (y(p+1)-y(p))/(x(p+1)-x(p));
end
function d = backward(y,x,p)
d = (y(p)-y(p-1))/(x(p)-x(p-1));
end
function d = central(y,x,p)
d = (y(p+1)-y(p-1))/(x(p+1)-x(p-1));
end