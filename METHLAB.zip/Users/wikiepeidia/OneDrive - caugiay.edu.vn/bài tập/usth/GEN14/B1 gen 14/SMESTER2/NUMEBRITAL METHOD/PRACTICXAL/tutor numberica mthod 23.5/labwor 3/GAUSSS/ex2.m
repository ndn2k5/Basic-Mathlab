clc,clear all,close all
A=[2 1 -1;-3 -1 2;-2 1 2];
b=[8 -11 -3];
X=inv(A)*b';
Y=A\b';
Z=mldivide(A,b');
T=gausspivot(A,b')
U=naivegauss(A,b')