clc,clear all,close all
A=[1;1;1]*[1:5]
B=[0:4]'*[1 1 1]