function [x, y] = newton_raphson(u, v, initial_guess, tol, max_iter)
    % Initialize variables
    x = initial_guess(1);
    y = initial_guess(2);
    iter = 0;
    
    % Define the Jacobian matrix function
    J = @(x, y) [2*x + y, x; 3*y^2, 1 + 6*x*y];
    
    % Define the function F
    F = @(x, y) [u(x, y); v(x, y)];
    
    % Main loop
    while iter < max_iter
        % Compute Jacobian and function values
        J_val = J(x, y);
        F_val = F(x, y);
        
        % Solve for the update using matrix inversion
        update = J_val \ (-F_val);
        
        % Update x and y
        x = x + update(1);
        y = y + update(2);
        
        % Check convergence
        if norm(update) < tol
            break;
        end
        
        iter = iter + 1;
    end
end