%Pham THe Minh 23bi14279


clc; clear; close all
A = [5.1 3.2;2.1 4.3;-1 0; 0 -1];
B = [240;200;0;0];
Z = [-1.55; -1.75];
[t, fval, exitflag, output, lambda] = linprog(Z, A, B);
max_value = -fval
x = t(1)
y = t(2)