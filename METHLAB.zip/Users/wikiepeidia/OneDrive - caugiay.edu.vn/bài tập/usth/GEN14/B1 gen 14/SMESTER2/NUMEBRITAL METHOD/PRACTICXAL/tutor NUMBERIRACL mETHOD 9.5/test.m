clc,clear,close all
a=4;
b=5;
c=a+b
