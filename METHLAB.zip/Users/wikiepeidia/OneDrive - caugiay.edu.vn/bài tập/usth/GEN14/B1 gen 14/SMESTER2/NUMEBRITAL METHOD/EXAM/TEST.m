clc,clear,close all
sym x;
step=1;

x=1;
while step>0
    x=x-f(x)/df(x);
    step=step-1;
end
function y=f(x)
sin(x)-x.^2+2;
end
function y=df(x)
cos(x)-2*x;
end