clc,close,clear all
syms k
syms n
a=symsum(1/k-1/(1+k), k, 1, inf)
b=symsum(1/n^2, n, 1, inf)