clc,clear,close all
func=@(x)x^2-9;
options=optimset("Display","iter");
fzero(func,-1)
fzero(func,0,options)
fzero(func,1)