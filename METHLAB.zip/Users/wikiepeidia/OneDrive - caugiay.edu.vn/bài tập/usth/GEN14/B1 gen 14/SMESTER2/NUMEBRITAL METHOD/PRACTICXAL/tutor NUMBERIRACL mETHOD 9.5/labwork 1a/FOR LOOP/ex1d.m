clc;        % Clear command window
clear all;  % Clear all variables from the workspace
close all;  % Close all open figures
S=0;
n=inf;
for k=1:2:n
    S=S+1(k^2(k+2)^2);
end
A=(pi^2-8)/16;
if floor(S)==floor(A)
    print