clc,close,clear all
x=[1 2 3 4 5]
x'