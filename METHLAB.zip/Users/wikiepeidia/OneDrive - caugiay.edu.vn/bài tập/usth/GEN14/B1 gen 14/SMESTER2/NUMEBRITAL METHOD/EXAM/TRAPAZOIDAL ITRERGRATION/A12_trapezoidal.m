f = @(x) 8+4*cos(x);
a = 0; %(LOW)
b = pi/2; %(HIGH)
n = 4; %number of segments. For single rule TRAPAZIOODDOODIAL: n = 1

I = 0;
h = (b-a)/n;
for i = 0:n-1
    x0 = a + i * h;
    x1 = a + (i + 1) * h;
    I = I + 0.5 * h * (f(x0) + f(x1));
end

fprintf('Approximate integral value: %.5f\n', I);