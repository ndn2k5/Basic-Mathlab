x=linspace(0,6);
y1=-3/2*x+9;
y2=1/2*x+1;
plot(x,y1);
hold on
plot(x,y2);