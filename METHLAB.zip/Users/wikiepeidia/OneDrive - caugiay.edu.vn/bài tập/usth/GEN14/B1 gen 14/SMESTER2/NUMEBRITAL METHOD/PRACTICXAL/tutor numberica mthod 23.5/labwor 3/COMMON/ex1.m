clc,clear all,close all
x=[1:20]';
y=ones(20,1);
z=x+y;
t=dot(x,y);
p=[1,5,16,length(z)];
z(p)=z(p)+3;
z(p)=z(p)*6