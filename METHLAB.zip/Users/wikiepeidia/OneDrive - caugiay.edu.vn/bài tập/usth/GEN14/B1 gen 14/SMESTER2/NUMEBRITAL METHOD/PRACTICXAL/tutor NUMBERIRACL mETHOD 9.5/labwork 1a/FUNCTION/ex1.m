clc;        % Clear command window
clear all;  % Clear all variables from the workspace
close all;  % Close all open figures

% Prompt the user to enter a vector
x = input('Enter vector x: ');

% Calculate the mean using a local function
mean(x)

% Display the calculated mean


% Local function to calculate mean
function m = mean(x)
    m = sum(x) / length(x);
end
