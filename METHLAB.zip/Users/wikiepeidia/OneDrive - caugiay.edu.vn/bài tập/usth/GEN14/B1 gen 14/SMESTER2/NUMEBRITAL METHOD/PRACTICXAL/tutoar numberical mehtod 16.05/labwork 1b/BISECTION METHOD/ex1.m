clc,close,clear all
syms x;
bisection(@f,0.5,2,0.0001,3) 

function y = f(x)
    y = log(x^2)-0.7;
end
