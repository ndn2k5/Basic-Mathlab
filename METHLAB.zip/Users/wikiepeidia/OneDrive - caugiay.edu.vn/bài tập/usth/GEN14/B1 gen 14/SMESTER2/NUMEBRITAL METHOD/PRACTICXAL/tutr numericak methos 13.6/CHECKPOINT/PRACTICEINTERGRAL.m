clc,clear,close all
syms x;
%x=linspace(0,1);

func=@(x)exp(-x.^2);
f=func(x);
%I1=int(f,x) 
%I2=quad(func,0,1)
I3=int(f,-inf,inf) 
