function GaussSeidel(A, b, x0, iterations)
  % A: Coefficient matrix
  % b: Right-hand side vector
  % x0: Initial guess vector
  % iterations: Number of iterations

  n = length(b);
  x = x0;

  function e = calError(new, old)
    e = abs((new - old) ./ (new + eps)) * 100; % Adding eps to avoid division by zero
  end

  for k = 1:iterations
    x_old = x;

    for i = 1:n
      sum1 = A(i, 1:i-1) * x(1:i-1);
      sum2 = A(i, i+1:n) * x(i+1:n);
      x(i) = (b(i) - sum1 - sum2) / A(i, i);
    end

    errors = calError(x, x_old);

    fprintf("Iteration %d: ", k);
    for i = 1:n
      fprintf("x%d = %.5f ", i, x(i));
    end
    fprintf(" | ");
    for i = 1:n
      fprintf("e%d = %.3f ", i, errors(i));
    end
    fprintf("\n");
  end
end
