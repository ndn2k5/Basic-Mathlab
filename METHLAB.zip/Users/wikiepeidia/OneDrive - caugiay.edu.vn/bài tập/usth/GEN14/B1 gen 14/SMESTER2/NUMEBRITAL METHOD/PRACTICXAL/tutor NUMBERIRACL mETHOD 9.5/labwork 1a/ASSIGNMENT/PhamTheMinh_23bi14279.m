clc;       
clear all;  
close all;  
%Pham THe Minh 23bi14279 C5 24/09/2005
A=[2 0 1; 0 7 0; 1 0 9]
B=[24 1 0; 1 0 1;0 1 9]
%question a
C=A+B
D=A-B
E=A*B
F=A.*B
%question b
x=A(1,2)
%question c
y=B(3,1)
%question d
Ac2=[A(:,2)]
%question e
A(2, :) = [];
disp(A)
%question f
B(:, 2) = [];
B(2, :) = [];
disp(B)