A = [
    4 1 -1;
    5 1 2;
    6 1 1
]%AUG MATRIX 
b = [-2;4;6];%B GO DOWN LINE NO NEED TRANPOSE

x = GaussNaive(A,b);

disp('Solutions:');
disp(x);