clc;        % Clear command window
clear all;  % Clear all variables from the workspace
close all;  % Close all open figures
syms kwh elec
kwh=input("enter the value of electricty ")
if kwh<=0
    error("invalid inut")
end
if 0<kwh<=50
    elec=1484*kwh
elseif 50<kwh<=100
    elec=1533*kwh
elseif 100<kwh<=200
    elec=1786*kwh
elseif 200<kwh<=300
    elec=2242*kwh
elseif 300<kwh<=400
    elec=2503*kwh
else
    elec=2587*kwh
end