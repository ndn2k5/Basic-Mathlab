clc;        % Clear command window
clear all;  % Clear all variables from the workspace
close all;  % Close all open figures

% Prompt for coefficients
a = input('Enter a: ');
b = input('Enter b: ');
c = input('Enter c: ');

% Calculate roots
[x1, x2] = EQN(a, b, c);

% Local function to solve quadratic equation
function [x1, x2] = EQN(a, b, c)
    if a == 0
        error('Invalid equation: a cannot be zero in a quadratic equation.');
    end

    delta = b^2 - 4*a*c;

    if delta < 0
        error('No real solution because the discriminant (delta) is less than zero.');
    elseif delta == 0
        x1 = -b / (2*a);
        x2 = x1; % both roots are the same in this case
        disp(['The function has one real solution: ', num2str(x1)]);
    else
        x1 = (-b + sqrt(delta)) / (2*a);
        x2 = (-b - sqrt(delta)) / (2*a);
        disp(['The function has two real solutions: ', num2str(x1), ' and ', num2str(x2)]);
    end
end
