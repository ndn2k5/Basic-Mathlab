% Maximize: 150x + 175y
% Constraints:
% 7x + 11y <= 77
% 10x + 8y <= 80
% 0 <= x <= 9
% 0 <= y <= 6
% pkg load optim %remove if matlab

c = [-45; -20]; % Profit per unit for products A and B
A = [
    20 5;    % Required material per unit product
    0.04 0.12; % Production time per unit product
    1 1     % Storage/production constraint per unit product
];
b = [
    9500; % Available material
    40;   % Available production time
    550   % Storage capacity
];

lb = [0; 0]; % Lower bounds (can't produce negative units)
ub = [450; 100]; % Upper bounds (maximum production capacities for A and B)

[x, fval] = linprog(c, A, b, [], [], lb, ub);

disp('Solution:');
disp(x);
disp('Objective function value (maximized):');
disp(-fval);
